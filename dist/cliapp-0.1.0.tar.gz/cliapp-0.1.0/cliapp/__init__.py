# cliapp/__init__.py

from .core import run_app
