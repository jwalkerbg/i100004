# README.md

How to prepare instalaltion
  python setup.py sdist bdist_wheel
How to run:
  python -m cliapp --name AnyName